import selenium
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from time import time
from tqdm import tqdm
from fake_useragent import UserAgent
from webdriver_manager.chrome import ChromeDriverManager
from time import time
from collections import defaultdict
from tqdm import tqdm
import itertools
from multiprocessing import Pool
import multiprocessing

def get_driver(driver_name='chrome'):

    def get_firefox_driver():
        options = Options()
        options.headless = True 

        user_agent = UserAgent().random
        profile = webdriver.FirefoxProfile()
        profile.set_preference("general.useragent.override", user_agent)

        driver = webdriver.Firefox(options=options, firefox_profile=profile)
        return driver


    def get_chrome_driver():
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        wd = webdriver.Chrome('chromedriver', options=chrome_options)

        ua = UserAgent()
        userAgent = ua.random
        chrome_options.add_argument(f'user-agent={userAgent}')
        
        chromedriver_path = '/Users/ypudyakov/opt/anaconda3/envs/hh_parse/lib/python3.6/site-packages/chromedriver_py/chromedriver_mac64_m1'
        driver = webdriver.Chrome(executable_path=chromedriver_path, options=chrome_options)

        return driver 

    def get_colab_chrome_driver():
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        
        ua = UserAgent()
        userAgent = ua.random
        chrome_options.add_argument(f'user-agent={userAgent}')

        wd = webdriver.Chrome('chromedriver',options=chrome_options)
        return wd

    if driver_name == 'chrome':
        return get_chrome_driver()
    elif driver_name == 'firefox':
        return get_firefox_driver()
    elif driver_name == 'chrome_colab':
        return get_colab_chrome_driver()
    else:
        raise ValueError("Illegal 'driver_name' argument value. Use 'firefox', 'chrome', 'chrome_colab'")


# driver = get_driver('chrome_colab')

class WebDriverPool(object):
    def __init__(self, driver_names='chrome', num_drivers=20):
        self.num_drivers = num_drivers
        self.drivers = self.get_drivers_pool(driver_names, num_drivers)

    def __iter__(self):
        for driver in self.drivers:
            yield driver

    def __getitem__(self, index):
        return self.drivers[index]

    def __len__(self):
        return self.num_drivers

    def get_drivers_pool(self, driver_names, num_drivers):
        if isinstance(driver_names, list):
            return [get_driver(driver_names[i]) for i in range(num_drivers)]
        if isinstance(driver_names, str):
            return [get_driver(driver_names) for i in range(num_drivers)]
        else:
            raise ValueError("Illegal 'driver_names' argument class type. Pass to the function list of names or sting value")

    def quit(self):
        for driver in self.drivers:
            driver.quit()
        return
    
# def init_drivers(driver_names = 'chrome', num_drivers = multiprocessing.cpu_count()):
#     DRIVERS = WebDriverPool(driver_names, num_drivers)
#     return DRIVERS
