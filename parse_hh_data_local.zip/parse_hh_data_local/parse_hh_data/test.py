from joblib import Parallel, delayed
from multiprocessing import Pool
import multiprocessing
import multiprocessing
import timeit

import requests
from bs4 import BeautifulSoup
from requests.exceptions import HTTPError, ConnectionError, Timeout
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem

SOFTWARE_NAMES = [SoftwareName.CHROME.value]
OPERATING_SYSTEMS = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
USER_AGENT = UserAgent(software_names=SOFTWARE_NAMES, operating_systems=OPERATING_SYSTEMS, limit=100)

import sys
sys.setrecursionlimit(5000)

urls =  ['879e4b2400018d675a0039ed1f6975444a7348',
         '35186d1b0006dfda270039ed1f3478627a7451',
         'd001d74900065f3d4d0039ed1f3466686e7a56',
         'c72465c0000031ffae0039ed1f736563726574',
         '2ba6aef600075028fd0039ed1f385072576368',
         '642a14d70001e513c60039ed1f47546a50726c',
         'ab0d9e2c00008f76a40039ed1f736563726574',
         '0d6fe3920003249c340039ed1f753244324652',
         'ad91cd9d0002b3ac370039ed1f673877335053',
         '75615c370008e3fd8b0039ed1f624f42446d74',
         'fcc2c26600083db63c0039ed1f706469736663',
         '8b5e56fa0000003cc10039ed1f736563726574',
         '52c304ba000404be750039ed1f6a49314c7379',
         'b2fa210800017ac5e00039ed1f6e6c6a705a36',
         'da5d25c70005f5e94c0039ed1f6f4b4e785839',
         '82590ef000004df6a20039ed1f736563726574',
         'd69be9d30000a738f20039ed1f736563726574',
         '0d5f92c40001e378ea0039ed1f62616c4a507a',
         'be28a03400028a5b130039ed1f354b78466772',
         '7324e47700029a2cb40039ed1f4a6434775171',
         '2a1129840002cee5bb0039ed1f575547387673',
         '45714ac5000429c1070039ed1f4561504b677a',
         '65b3d2e70000648e520039ed1f736563726574',
         '57716e2c0000c8fba10039ed1f476c50385268',
         'faca82980003bac2010039ed1f616e39725475',
         'f601c57600077bee080039ed1f4264735a3732',
         'fa903f490004151f4a0039ed1f4f5934634359',
         'aaaa82090004094bc80039ed1f35525a635148',
         '99ef6ef800044f9c740039ed1f6d446e555243',
         '4cc8f7860002dc36e40039ed1f4d7a3269484c',
         'f70cf28a0003deb06d0039ed1f624b4e61344a',
         'ea4075430007f1605e0039ed1f77696c747737']

BASE_URL = 'https://hh.ru/resume/'
def get_bs_resume(url):
    print('start')
    url = BASE_URL + url
    resp = requests.get(url, headers={'User-Agent': USER_AGENT.get_random_user_agent()}, timeout=10)
    html = resp.text
    soup = BeautifulSoup(html, "html.parser")
    print('end')
    return soup

# if __name__ == "__main__":
#     inputs = [url for i in range(20)]
# #     num_cores = multiprocessing.cpu_count()
# #     p = Pool(num_cores)
# #     t1 = timeit.Timer()
# #     result = p.map(get_bs_resume, inputs)
# #     p.close()
# #     p.join()
# #     print(t1.timeit(1))
# #     print(result)    
    
    
#     # inputs = [i for i in range(32)]
#     num_cores = multiprocessing.cpu_count()
#     t1 = timeit.Timer()
#     result = Parallel(n_jobs=num_cores)(delayed(get_bs_resume)(i) for i in inputs)
#     print(t1.timeit(1)) 
    
# def g(x):
#     return x**3 + 2


# def f(x):    
#     return x**2, g(x)

if __name__ == "__main__":
    # urls = [url for i in range(25)]
    num_cores = multiprocessing.cpu_count()
    p = Pool(num_cores)
    t1 = timeit.Timer()
    result = p.map(get_bs_resume, urls)
    p.close()
    p.join()
    print(t1.timeit(1))
    print(result)    