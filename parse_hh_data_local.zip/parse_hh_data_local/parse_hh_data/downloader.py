from .driver import WebDriverPool
from bs4 import BeautifulSoup
import multiprocessing

DRIVERS = None
N_DRIVERS = None
RESUME_BASE_URL = 'https://hh.ru/resume/'

def initialize_drivers(driver_names = 'chrome', num_drivers = multiprocessing.cpu_count()):
    global DRIVERS, N_DRIVERS
    DRIVERS = WebDriverPool(driver_names, num_drivers)
    N_DRIVERS = len(DRIVERS)
    return

def download(driver_ind, resume_idx):
    print('Start: {}'.format(driver_ind))
    driver = DRIVERS[driver_ind % len(DRIVERS)]
    url = RESUME_BASE_URL + resume_idx
    driver.get(url)
    html = driver.page_source
    bs_html = BeautifulSoup(html, "html.parser")
    print('End: {}'.format(driver_ind))
    return bs_html